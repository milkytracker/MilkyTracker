//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by main.rc
//
#define IDS_APP_TITLE                   1
#define IDS_HELLO                       2
#define IDC_FIRSTGX                     3
#define IDI_FIRSTGX                     101
#define IDM_MENU                        102
#define IDD_ABOUTBOX                    103
#define IDS_HELP                        104
#define IDI_ICON1                       106
#define IDS_COMMAND1                    301
#define IDM_MAIN_COMMAND1               40001
#define IDM_HELP_ABOUT                  40003

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        111
#define _APS_NEXT_COMMAND_VALUE         40004
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
